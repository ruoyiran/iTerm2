import{a as H}from"./chunk-4NXIANNJ.js";import{G as P,N as L,S as I,Z as X,h as Y,t as A}from"./chunk-PZ7VOONP.js";import{b as x}from"./chunk-3Q7XHBEG.js";import{a as h}from"./chunk-TXLOGYIB.js";import{a as B}from"./chunk-EWWMMUA7.js";B();var M="",O="",D="",E=[],b=new Map,v=h(e=>P(e,X()),"sanitizeText"),y=h(e=>{switch(e.type){case"terminal":return{...e,value:v(e.value)};case"nonterminal":return{...e,name:v(e.name)};case"sequence":return{...e,elements:e.elements.map(y)};case"choice":return{...e,alternatives:e.alternatives.map(y)};case"optional":return{...e,element:y(e.element)};case"repetition":return{...e,element:y(e.element),separator:e.separator?y(e.separator):void 0};case"special":return{...e,text:v(e.text)}}},"sanitizeAstNode"),Q=h(()=>{M="",O="",D="",E.length=0,b.clear(),I(),x.debug("[Railroad] Database cleared")},"clear"),G=h(e=>{M=v(e),x.debug("[Railroad] Title set:",e)},"setTitle"),U=h(()=>M,"getTitle"),Z=h(e=>{let i={...e,name:v(e.name),definition:y(e.definition),comment:e.comment?v(e.comment):void 0};x.debug("[Railroad] Adding rule:",i.name),b.has(i.name)&&x.warn(`[Railroad] Rule '${i.name}' is already defined. Overwriting.`),E.push(i),b.set(i.name,i)},"addRule"),V=h(()=>E,"getRules"),ee=h(e=>b.get(e),"getRule"),te=h(e=>{O=v(e).replace(/^\s+/g,""),x.debug("[Railroad] Accessibility title set:",e)},"setAccTitle"),re=h(()=>O,"getAccTitle"),ie=h(e=>{D=v(e).replace(/\n\s+/g,`
`),x.debug("[Railroad] Accessibility description set:",e)},"setAccDescription"),ne=h(()=>D,"getAccDescription"),ae=G,oe=U,le={clear:Q,setTitle:G,getTitle:U,addRule:Z,getRules:V,getRule:ee,setAccTitle:te,getAccTitle:re,setAccDescription:ie,getAccDescription:ne,setDiagramTitle:ae,getDiagramTitle:oe},f={compactMode:!1,padding:10,verticalSeparation:8,horizontalSeparation:10,arcRadius:10,fontSize:14,fontFamily:"monospace",terminalFill:"#FFFFC0",terminalStroke:"#000000",terminalTextColor:"#000000",nonTerminalFill:"#FFFFFF",nonTerminalStroke:"#000000",nonTerminalTextColor:"#000000",lineColor:"#000000",strokeWidth:2,markerFill:"#000000",commentFill:"#E8E8E8",commentStroke:"#888888",commentTextColor:"#666666",specialFill:"#F0E0FF",specialStroke:"#8800CC",ruleNameColor:"#000066",showMarkers:!0,markerRadius:5},se=/^#(?:[\da-f]{3,4}|[\da-f]{6}|[\da-f]{8})$|^(?:rgb|rgba|hsl|hsla|hwb|lab|lch|oklab|oklch)\([\d\s%+,./-]+\)$|^[a-z]+$/i,de=/^[\w "',.-]+$/,ce=new Set(["compactMode","padding","verticalSeparation","horizontalSeparation","arcRadius","fontSize","fontFamily","terminalFill","terminalStroke","terminalTextColor","nonTerminalFill","nonTerminalStroke","nonTerminalTextColor","lineColor","strokeWidth","markerFill","commentFill","commentStroke","commentTextColor","specialFill","specialStroke","ruleNameColor","showMarkers","markerRadius"]),j=h(e=>e?Object.keys(e).every(i=>i==="railroad"||ce.has(i)):!1,"isRailroadStyleOptions"),me=h(e=>e?"railroad"in e&&e.railroad?e.railroad:j(e)?e:{}:{},"extractRailroadOverrides"),he=h(e=>{if(!e||j(e))return{};let{railroad:i,svgId:a,theme:n,look:t,...r}=e;return r},"extractThemeOverrides"),m=h((e,i)=>{if(typeof e!="string")return i;let a=e.trim();return se.test(a)?a:i},"sanitizeColorValue"),K=h((e,i)=>{if(typeof e!="string")return i;let a=e.trim();return de.test(a)?a:i},"sanitizeFontFamilyValue"),F=h((e,i)=>{let a=typeof e=="number"?e:typeof e=="string"?Number.parseFloat(e):Number.NaN;return Number.isFinite(a)&&a>=0?a:i},"sanitizeNumberValue"),pe=h(e=>{let i=typeof e=="number"?e:typeof e=="string"?Number.parseFloat(e):Number.NaN;return Number.isFinite(i)&&i>0?i:void 0},"parseThemeFontSize"),ue=h(e=>{let i=K(e.fontFamily,f.fontFamily),a=pe(e.fontSize)??f.fontSize;return{...f,fontFamily:i,fontSize:a,terminalFill:m(e.secondBkg??e.secondaryColor,f.terminalFill),terminalStroke:m(e.secondaryBorderColor??e.lineColor,f.terminalStroke),terminalTextColor:m(e.secondaryTextColor??e.textColor,f.terminalTextColor),nonTerminalFill:m(e.mainBkg??e.background,f.nonTerminalFill),nonTerminalStroke:m(e.primaryBorderColor??e.lineColor,f.nonTerminalStroke),nonTerminalTextColor:m(e.primaryTextColor??e.textColor,f.nonTerminalTextColor),lineColor:m(e.lineColor,f.lineColor),markerFill:m(e.lineColor,f.markerFill),commentFill:m(e.labelBackground??e.tertiaryColor,f.commentFill),commentStroke:m(e.tertiaryBorderColor??e.lineColor,f.commentStroke),commentTextColor:m(e.tertiaryTextColor??e.textColor,f.commentTextColor),specialFill:m(e.tertiaryColor??e.secondaryColor,f.specialFill),specialStroke:m(e.tertiaryBorderColor??e.secondaryBorderColor,f.specialStroke),ruleNameColor:m(e.titleColor??e.textColor,f.ruleNameColor)}},"buildThemeDefaults"),W=h(e=>{let i=A(),a={...Y(),...i.themeVariables??{},...he(e)},n=ue(a),t={...i.railroad??{},...me(e)};return{compactMode:t.compactMode??n.compactMode,padding:F(t.padding,n.padding),verticalSeparation:F(t.verticalSeparation,n.verticalSeparation),horizontalSeparation:F(t.horizontalSeparation,n.horizontalSeparation),arcRadius:F(t.arcRadius,n.arcRadius),fontSize:F(t.fontSize,n.fontSize),fontFamily:K(t.fontFamily,n.fontFamily),terminalFill:m(t.terminalFill,n.terminalFill),terminalStroke:m(t.terminalStroke,n.terminalStroke),terminalTextColor:m(t.terminalTextColor,n.terminalTextColor),nonTerminalFill:m(t.nonTerminalFill,n.nonTerminalFill),nonTerminalStroke:m(t.nonTerminalStroke,n.nonTerminalStroke),nonTerminalTextColor:m(t.nonTerminalTextColor,n.nonTerminalTextColor),lineColor:m(t.lineColor,n.lineColor),strokeWidth:F(t.strokeWidth,n.strokeWidth),markerFill:m(t.markerFill,n.markerFill),commentFill:m(t.commentFill,n.commentFill),commentStroke:m(t.commentStroke,n.commentStroke),commentTextColor:m(t.commentTextColor,n.commentTextColor),specialFill:m(t.specialFill,n.specialFill),specialStroke:m(t.specialStroke,n.specialStroke),ruleNameColor:m(t.ruleNameColor,n.ruleNameColor),showMarkers:t.showMarkers??n.showMarkers,markerRadius:F(t.markerRadius,n.markerRadius)}},"buildRailroadStyleOptions"),ve=h(e=>{let{fontFamily:i,fontSize:a,terminalFill:n,terminalStroke:t,terminalTextColor:r,nonTerminalFill:o,nonTerminalStroke:g,nonTerminalTextColor:l,lineColor:s,strokeWidth:p,markerFill:u,commentFill:c,commentStroke:C,commentTextColor:d,specialFill:T,specialStroke:z,ruleNameColor:S}=W(e);return`
  .railroad-diagram {
    font-family: ${i};
    font-size: ${a}px;
  }

  .railroad-terminal rect {
    fill: ${n};
    stroke: ${t};
    stroke-width: ${p}px;
  }

  .railroad-terminal text {
    fill: ${r};
    font-family: ${i};
    font-size: ${a}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-nonterminal rect {
    fill: ${o};
    stroke: ${g};
    stroke-width: ${p}px;
  }

  .railroad-nonterminal text {
    fill: ${l};
    font-family: ${i};
    font-size: ${a}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-line {
    stroke: ${s};
    stroke-width: ${p}px;
    fill: none;
  }

  .railroad-start circle,
  .railroad-end circle {
    fill: ${u};
  }

  .railroad-comment ellipse {
    fill: ${c};
    stroke: ${C};
    stroke-width: ${p}px;
  }

  .railroad-comment text {
    fill: ${d};
    font-style: italic;
    font-family: ${i};
    font-size: ${a}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-special rect {
    fill: ${T};
    stroke: ${z};
    stroke-width: ${p}px;
    stroke-dasharray: 5,3;
  }

  .railroad-special text {
    fill: ${l};
    font-family: ${i};
    font-size: ${a}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-rule-name {
    font-weight: bold;
    fill: ${S};
    font-family: ${i};
    font-size: ${a}px;
  }

  .railroad-group {
    /* Grouping container, no specific styles */
  }
`},"getStyles"),R,w=(R=class{constructor(){this.d=""}moveTo(i,a){return this.d+=`M ${i} ${a} `,this}lineTo(i,a){return this.d+=`L ${i} ${a} `,this}horizontalTo(i){return this.d+=`H ${i} `,this}verticalTo(i){return this.d+=`V ${i} `,this}arcTo(i,a,n,t,r,o,g){return this.d+=`A ${i} ${a} ${n} ${t?1:0} ${r?1:0} ${o} ${g} `,this}build(){return this.d.trim()}},h(R,"PathBuilder"),R),$,ge=($=class{constructor(i,a=W()){this.textCache=new Map,this.svg=i,this.config=a}measureText(i){if(this.textCache.has(i))return this.textCache.get(i);let a=this.svg.append("text").attr("font-family",this.config.fontFamily).attr("font-size",this.config.fontSize).text(i),n=a.node().getBBox(),t={width:n.width,height:n.height};return a.remove(),this.textCache.set(i,t),t}renderTerminal(i,a){let n=this.measureText(a),t=n.width+this.config.padding*2,r=n.height+this.config.padding*2,o=i.append("g").attr("class","railroad-terminal");return o.append("rect").attr("x",0).attr("y",0).attr("width",t).attr("height",r).attr("rx",10).attr("ry",10),o.append("text").attr("x",t/2).attr("y",r/2).text(a),{element:o.node(),dimensions:{width:t,height:r,up:r/2,down:r/2}}}renderNonTerminal(i,a){let n=this.measureText(a),t=n.width+this.config.padding*2,r=n.height+this.config.padding*2,o=i.append("g").attr("class","railroad-nonterminal");return o.append("rect").attr("x",0).attr("y",0).attr("width",t).attr("height",r),o.append("text").attr("x",t/2).attr("y",r/2).text(a),{element:o.node(),dimensions:{width:t,height:r,up:r/2,down:r/2}}}renderSequence(i,a){let n=a.map(s=>this.renderExpression(i,s)),t=0,r=0,o=0;for(let s of n)t+=s.dimensions.width,r=Math.max(r,s.dimensions.up),o=Math.max(o,s.dimensions.down);t+=(n.length-1)*this.config.horizontalSeparation;let g=i.append("g").attr("class","railroad-sequence"),l=0;for(let s=0;s<n.length;s++){let p=n[s],u=r-p.dimensions.up;if(g.node().appendChild(p.element).setAttribute("transform",`translate(${l}, ${u})`),s<n.length-1){let C=l+p.dimensions.width,d=C+this.config.horizontalSeparation,T=r;g.append("path").attr("class","railroad-line").attr("d",new w().moveTo(C,T).lineTo(d,T).build())}l+=p.dimensions.width+this.config.horizontalSeparation}return{element:g.node(),dimensions:{width:t,height:r+o,up:r,down:o}}}renderChoice(i,a){let n=a.map(c=>this.renderExpression(i,c)),t=0,r=0;for(let c of n)t=Math.max(t,c.dimensions.width),r+=c.dimensions.height;r+=(n.length-1)*this.config.verticalSeparation;let o=this.config.arcRadius,g=o*4,l=t+g,s=i.append("g").attr("class","railroad-choice"),p=0,u=r/2;for(let c of n){let C=p,d=C+c.dimensions.up,T=o*2+(t-c.dimensions.width)/2;s.node().appendChild(c.element).setAttribute("transform",`translate(${T}, ${C})`);let S=new w,k=d>u;d===u?S.moveTo(0,u).lineTo(T,d):S.moveTo(0,u).arcTo(o,o,0,!1,k,o,u+(k?o:-o)).lineTo(o,d-(k?o:-o)).arcTo(o,o,0,!1,!k,o*2,d).lineTo(T,d),s.append("path").attr("class","railroad-line").attr("d",S.build());let N=new w,_=T+c.dimensions.width,J=l-o*2;d===u?N.moveTo(_,d).lineTo(l,u):N.moveTo(_,d).lineTo(J,d).arcTo(o,o,0,!1,!k,l-o,d+(k?-o:o)).lineTo(l-o,u+(k?o:-o)).arcTo(o,o,0,!1,k,l,u),s.append("path").attr("class","railroad-line").attr("d",N.build()),p+=c.dimensions.height+this.config.verticalSeparation}return{element:s.node(),dimensions:{width:l,height:r,up:u,down:r-u}}}renderOptional(i,a){let n=this.renderExpression(i,a),t=this.config.arcRadius,r=t*2,o=n.dimensions.width+t*4,g=n.dimensions.height+r,l=i.append("g").attr("class","railroad-optional"),s=t*2,p=r;l.node().appendChild(n.element).setAttribute("transform",`translate(${s}, ${p})`);let c=p+n.dimensions.up,C=new w().moveTo(0,c).lineTo(t*2,c);l.append("path").attr("class","railroad-line").attr("d",C.build());let d=new w().moveTo(s+n.dimensions.width,c).lineTo(o,c);l.append("path").attr("class","railroad-line").attr("d",d.build());let T=new w().moveTo(0,c).arcTo(t,t,0,!1,!1,t,c-t).lineTo(t,t).arcTo(t,t,0,!1,!0,t*2,0).lineTo(o-t*2,0).arcTo(t,t,0,!1,!0,o-t,t).lineTo(o-t,c-t).arcTo(t,t,0,!1,!1,o,c);return l.append("path").attr("class","railroad-line").attr("d",T.build()),{element:l.node(),dimensions:{width:o,height:g,up:c,down:g-c}}}renderRepetition(i,a,n){let t=this.renderExpression(i,a),r=this.config.arcRadius,o=r*2,g=t.dimensions.width+r*4,l=n===0,s=t.dimensions.height+o+(l?o:0),p=i.append("g").attr("class","railroad-repetition"),u=r*2,c=l?o:0;p.node().appendChild(t.element).setAttribute("transform",`translate(${u}, ${c})`);let d=c+t.dimensions.up;p.append("path").attr("class","railroad-line").attr("d",new w().moveTo(0,d).lineTo(r*2,d).build()),p.append("path").attr("class","railroad-line").attr("d",new w().moveTo(u+t.dimensions.width,d).lineTo(g,d).build());let T=c+t.dimensions.height+r,z=new w().moveTo(u+t.dimensions.width,d).arcTo(r,r,0,!1,!0,u+t.dimensions.width+r,d+r).lineTo(u+t.dimensions.width+r,T).arcTo(r,r,0,!1,!0,u+t.dimensions.width,T+r).lineTo(r*2,T+r).arcTo(r,r,0,!1,!0,r,T).lineTo(r,d+r).arcTo(r,r,0,!1,!0,r*2,d);if(p.append("path").attr("class","railroad-line").attr("d",z.build()),l){let S=new w().moveTo(0,d).arcTo(r,r,0,!1,!1,r,d-r).lineTo(r,r).arcTo(r,r,0,!1,!0,r*2,0).lineTo(g-r*2,0).arcTo(r,r,0,!1,!0,g-r,r).lineTo(g-r,d-r).arcTo(r,r,0,!1,!1,g,d);p.append("path").attr("class","railroad-line").attr("d",S.build())}return{element:p.node(),dimensions:{width:g,height:s,up:d,down:s-d}}}renderSpecial(i,a){let n=this.measureText("? "+a+" ?"),t=n.width+this.config.padding*2,r=n.height+this.config.padding*2,o=i.append("g").attr("class","railroad-special");return o.append("rect").attr("x",0).attr("y",0).attr("width",t).attr("height",r),o.append("text").attr("x",t/2).attr("y",r/2).text("? "+a+" ?"),{element:o.node(),dimensions:{width:t,height:r,up:r/2,down:r/2}}}renderExpression(i,a){switch(a.type){case"terminal":return this.renderTerminal(i,a.value);case"nonterminal":return this.renderNonTerminal(i,a.name);case"sequence":return this.renderSequence(i,a.elements);case"choice":return this.renderChoice(i,a.alternatives);case"optional":return this.renderOptional(i,a.element);case"repetition":return this.renderRepetition(i,a.element,a.min);case"special":return this.renderSpecial(i,a.text);default:throw new Error(`Unknown node type: ${a.type}`)}}renderRule(i,a){let n=this.svg.append("g").attr("class","railroad-rule").attr("transform",`translate(0, ${a})`),t=i.name+" =",r=this.measureText(t).width+20,o=r+20,g=n.append("g"),l=this.renderExpression(g,i.definition),s=Math.max(20,l.dimensions.up),p=s-l.dimensions.up;return g.attr("transform",`translate(${o}, ${p})`),n.append("g").attr("class","railroad-rule-name-group").append("text").attr("class","railroad-rule-name").attr("x",0).attr("y",s).text(t),n.append("g").attr("class","railroad-start").append("circle").attr("cx",r).attr("cy",s).attr("r",this.config.markerRadius),n.append("g").attr("class","railroad-end").append("circle").attr("cx",o+l.dimensions.width+10).attr("cy",s).attr("r",this.config.markerRadius),n.append("path").attr("class","railroad-line").attr("d",new w().moveTo(r+this.config.markerRadius,s).lineTo(o,s).build()),n.append("path").attr("class","railroad-line").attr("d",new w().moveTo(o+l.dimensions.width,s).lineTo(o+l.dimensions.width+10-this.config.markerRadius,s).build()),{height:Math.max(40,p+l.dimensions.height+this.config.padding*2),width:o+l.dimensions.width+10+this.config.markerRadius}}renderDiagram(i){let a=this.config.padding,n=0;for(let t of i){let r=this.renderRule(t,a);a+=r.height+this.config.verticalSeparation,n=Math.max(n,r.width)}return{width:n+this.config.padding*2,height:a+this.config.padding}}},h($,"RailroadRenderer"),$),q=h((e,i,a)=>{L(e,i.height,i.width,a),e.attr("viewBox",`0 0 ${i.width} ${i.height}`)},"configureRailroadSvgSize"),fe=h((e,i,a)=>{x.debug(`[Railroad] Rendering diagram
`+e);try{let n=H(i);n.attr("class","railroad-diagram");let r=A().railroad?.useMaxWidth??!0,o=le.getRules();if(x.debug(`[Railroad] Rendering ${o.length} rules`),o.length===0){x.warn("[Railroad] No rules to render"),q(n,{height:100,width:200},r);return}let l=new ge(n,W()).renderDiagram(o);q(n,l,r),x.debug("[Railroad] Render complete")}catch(n){throw x.error("[Railroad] Render error:",n),n}},"draw"),Se={draw:fe};export{le as a,ve as b,Se as c};
